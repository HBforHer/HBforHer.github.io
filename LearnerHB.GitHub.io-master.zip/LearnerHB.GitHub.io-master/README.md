## 说明

此博客模板 Fork 自仓库：[cnfeat/blog.io: 简单直接可用博客模板](https://github.com/cnfeat/blog.io)

配套说用说明：[如何搭建一个独立博客——简明 GitHub Pages与 jekyll 教程 - 读立写生](http://www.cnfeat.com/blog/2014/05/10/how-to-build-a-blog/)

## 博客模板修订清单

文档内有详细注释，可按注释逐个修订

* 博客名字、作者信息、浏览器小图标等：_config.yml 
* 个人介绍页面：about.md
* 代表作页面：milestone.md
* 文章模板：blog.io/_posts/2015-03-02-how-to-write.md 
* 

## 模板作者

陈素封，博客：独立写生：[cnfeat.com](cnfeat.com)

联系方式：cnfeat@gmail.com


